# Serene — Website (Node.js)

Waitlist / early-access site for Serene. Same content, layout, and scroll-driven
product spin as the single-file version — restructured as a proper Node.js
project so it's easier to hand to a dev / Codex for continued work.

## Structure

```
serene-node/
├── server.js              # minimal Express static server
├── package.json
└── public/
    ├── index.html          # page markup
    ├── css/
    │   └── styles.css      # all site styles (design tokens, layout, mobile)
    ├── js/
    │   └── script.js       # scroll reveal, FAQ accordion, mode tabs,
    │                       # waitlist form submit, product spin scrubber
    └── assets/
        ├── images/          # product photography (bag-strap.jpg, case-kinfolk.jpg)
        └── frames/           # 48 transparent-background WebP frames
                                # (f_000.webp … f_047.webp) — the hero product
                                # spin, background-removed from Serene's own
                                # 360° video
```

No build step, no bundler — this is intentionally plain HTML/CSS/JS served by
Express. Easy to open, easy to edit, easy to hand off.

## Run locally

```bash
npm install
npm start
```

Then open **http://localhost:3000**

## Editing

- **Copy/content:** edit `public/index.html` directly — it's plain, readable markup.
- **Colors/spacing/fonts:** all defined as CSS variables at the top of
  `public/css/styles.css` under `:root{...}`.
- **Product spin frames:** if you get a new 360° video, re-extract and
  background-remove frames, then drop 48 (or however many) `f_000.webp …`
  files into `public/assets/frames/` — the frame count is set by
  `TOTAL_FRAMES` in `public/js/script.js`.
- **Spin amount / scroll length / speed:** in `public/js/script.js`, look for
  `SPIN_LOOPS` (rotation amount) and in `public/css/styles.css` look for
  `.hero-pin-track` (scroll distance, currently `140vh`).

## Waitlist form

The form posts to Netlify Forms (`data-netlify="true"` on the `<form>` in
`index.html`). This **only captures submissions when deployed on Netlify** —
if you deploy elsewhere (Render, Railway, your own server), swap in
Formspree or a small Express POST route in `server.js` that saves to a
database/spreadsheet instead.

## Deploying

**Option A — Netlify (static, keeps the waitlist form working out of the box):**
Since this is just static files, you can deploy `public/` directly to Netlify
(drag-and-drop the `public` folder, or connect this repo and set the publish
directory to `public`). The Express server isn't needed on Netlify — it's
only for local development / non-static hosts.

**Option B — Node hosting (Render, Railway, Fly.io, a VPS):**
Push this whole project, set the start command to `npm start`, and it'll run
`server.js` which serves everything in `public/`. If you go this route,
you'll need to replace the Netlify Forms submission with your own backend
(see "Waitlist form" above).

## Domain

Once deployed (either option), point your domain's DNS at your host per
their instructions, and enable HTTPS (automatic on Netlify/Render/Railway).
