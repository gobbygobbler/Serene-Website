/* ---------- Reveal on scroll ---------- */
const revealEls = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
},{ threshold:0.15 });
revealEls.forEach(el=>io.observe(el));

/* ---------- FAQ accordion ---------- */
document.querySelectorAll('.faq-item').forEach(item=>{
  item.addEventListener('click', ()=>{
    const wasOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(i=>i.classList.remove('open'));
    if(!wasOpen) item.classList.add('open');
  });
});

/* ---------- Mode tabs ---------- */
document.querySelectorAll('.mode-tab').forEach(tab=>{
  tab.addEventListener('click', ()=>{
    document.querySelectorAll('.mode-tab').forEach(t=>t.classList.remove('active'));
    tab.classList.add('active');
  });
});

/* ---------- Waitlist form — submits to Netlify Forms (works when deployed on Netlify) ---------- */
document.getElementById('waitlistForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const form = e.target;
  const data = new FormData(form);
  fetch('/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(data).toString()
  })
  .then(()=>{
    document.getElementById('formMsg').style.display='block';
    form.reset();
  })
  .catch(()=>{
    // even if the request errors client-side, Netlify has usually already recorded the submission
    document.getElementById('formMsg').style.display='block';
    form.reset();
  });
});

/* ---------- Real product spin — frame sequence extracted from Serene's own 360° video ---------- */
const TOTAL_FRAMES = 48;
const FRAME_PATH = (i)=> `assets/frames/f_${String(i).padStart(3,'0')}.webp`;
const SPIN_LOOPS = 200/360; // 200° total across the pinned scroll range

const frameImages = new Array(TOTAL_FRAMES);
let framesLoaded = 0;
let firstFrameReady = false;

const canvas = document.getElementById('cadCanvas');
const ctx = canvas.getContext('2d');
let currentFrameIndex = 0;

function sizeCanvas(){
  const wrap = canvas.parentElement;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = wrap.clientWidth, h = wrap.clientHeight;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  ctx.setTransform(dpr,0,0,dpr,0,0);
}

function drawFrame(idx){
  const img = frameImages[idx];
  if(!img || !img.complete || img.naturalWidth === 0) return;
  const wrap = canvas.parentElement;
  const w = wrap.clientWidth, h = wrap.clientHeight;
  ctx.clearRect(0,0,w,h);
  // contain-fit the frame inside the canvas box, then zoom in slightly so the product reads bigger
  const ZOOM = 0.85;
  const scale = Math.min(w / img.naturalWidth, h / img.naturalHeight) * ZOOM;
  const dw = img.naturalWidth * scale, dh = img.naturalHeight * scale;
  const dx = (w - dw) / 2, dy = (h - dh) / 2;
  ctx.drawImage(img, dx, dy, dw, dh);
}

function preloadFrames(){
  for(let i=0;i<TOTAL_FRAMES;i++){
    const img = new Image();
    img.onload = ()=>{
      framesLoaded++;
      if(!firstFrameReady){
        firstFrameReady = true;
        sizeCanvas();
        drawFrame(0);
      }
    };
    img.src = FRAME_PATH(i);
    frameImages[i] = img;
  }
}

function onResize(){
  sizeCanvas();
  drawFrame(currentFrameIndex);
}

/* Scroll progress across the pinned hero track drives which frame is shown.
   Raw scroll position is smoothed (lerp) each animation frame so the spin feels
   fluid instead of snapping — and it settles/holds still once you stop scrolling. */
const heroTrack = document.getElementById('heroTrack');
let targetProgress = 0;
let smoothedProgress = 0;
const SMOOTHING = 0.09;

function readScrollTarget(){
  const rect = heroTrack.getBoundingClientRect();
  const total = heroTrack.offsetHeight - window.innerHeight;
  let progress = total > 0 ? (-rect.top / total) : 0;
  targetProgress = Math.max(0, Math.min(1, progress));
}

function applyProgress(progress){
  const spinProgress = (progress * SPIN_LOOPS) % 1;
  const idx = Math.min(TOTAL_FRAMES - 1, Math.floor(spinProgress * TOTAL_FRAMES));
  if(idx !== currentFrameIndex || !firstFrameReady){
    currentFrameIndex = idx;
    drawFrame(idx);
  }

  const heroHeading = document.querySelector('.hero-heading');
  const heroSub = document.querySelector('.hero-sub');
  const heroCta = document.querySelector('.hero-cta-row');
  const fadeOut = Math.max(0, 1 - progress*3.2);
  [heroHeading,heroSub,heroCta].forEach(el=>{ if(el) el.style.opacity = fadeOut; });
}

function tick(){
  smoothedProgress += (targetProgress - smoothedProgress) * SMOOTHING;
  if(Math.abs(targetProgress - smoothedProgress) < 0.0006) smoothedProgress = targetProgress;
  applyProgress(smoothedProgress);
  requestAnimationFrame(tick);
}

window.addEventListener('scroll', readScrollTarget, { passive:true });
window.addEventListener('resize', ()=>{ sizeCanvas(); drawFrame(currentFrameIndex); });
window.addEventListener('load', ()=>{ preloadFrames(); sizeCanvas(); readScrollTarget(); requestAnimationFrame(tick); });
/* also run immediately in case 'load' already fired */
if(document.readyState === 'complete'){ preloadFrames(); sizeCanvas(); readScrollTarget(); requestAnimationFrame(tick); }
