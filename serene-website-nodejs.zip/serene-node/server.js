const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve everything in /public as static files (index.html, css/, js/, assets/)
app.use(express.static(path.join(__dirname, 'public')));

// Fallback to index.html for any other route (keeps this a clean single-page site)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Serene site running at http://localhost:${PORT}`);
});
